from distutils.core import setup

setup(
        name            = 'fonction_liste',
        version         = '1.0.0',
        py_modules      = ['fonction_liste'],
        author          = 'David GILLARD',
        author_email    = 'david.gillard@ac-lille.fr',
        description     = 'Affiche des listes imbriquées',
)